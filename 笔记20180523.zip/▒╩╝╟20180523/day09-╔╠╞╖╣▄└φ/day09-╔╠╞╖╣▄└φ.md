# 0.学习目标

1. 能够独立实现商品新增功能
2. 能够独立实现商品编辑功能



# 1.修改商品

修改商品，难点在于回显。之前我们在品牌页面已经完成了一次回显。所以商品的修改应该会熟悉一些。

## 1.1.修改按钮事件绑定

首先，肯定是给修改的按钮绑定点击事件，然后弹窗，并且设置修改标记为true。



按钮：

```html
<my-goods-form :step="step" @close="closeWindow" :is-edit="isEdit"/>
```

事件函数：

```js
editGoods(oldGoods) {
    // 修改标记
    this.isEdit = true;
    // 控制弹窗可见：
    this.show = true;
    // 获取要编辑的goods
    this.oldGoods = oldGoods;
}
```

传递当前商品数据：

![1526379881902](assets/1526379881902.png)

效果：

![1526376622326](assets/1526376622326.png)



## 1.2.查询商品详情

刚才虽然传递了商品数据，但是我们发现，数据并不完整：

 ![1526376756432](assets/1526376756432.png)



所以，我们在打开窗口前，应该先查询spuDetail数据。

### 1.2.1.页面发起请求

```js
editGoods(oldGoods) {
    // 发起请求，查询商品详情
    this.$http.get("/item/spu/detail/" + oldGoods.id)
        .then(({data}) => {
        oldGoods.spuDetail = data;
        // 修改标记
        this.isEdit = true;
        // 控制弹窗可见：
        this.show = true;
        // 获取要编辑的goods
        this.oldGoods = oldGoods;
    })
}
```



### 1.2.2.后台接口

> controller

```java
@GetMapping("/spu/detail/{id}")
public ResponseEntity<SpuDetail> querySpuDetailById(@PathVariable("id") Long id) {
    SpuDetail detail = this.goodsService.querySpuDetailById(id);
    if (detail == null) {
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    return ResponseEntity.ok(detail);
}
```

> service

```java
public SpuDetail querySpuDetailById(Long id) {
    return this.spuDetailMapper.selectByPrimaryKey(id);
}
```

再次测试页面：

 ![1526385627967](assets/1526385627967.png)

spuDetail已经查到

## 1.3.基本数据回显

在MyGoodsForm页面，我们通过watch监控传递过来的oldGoods的变化，如果发现是编辑状态，就把传递过来的oldGoods接收并赋值给自己的goods：

```js
oldGoods:{
    deep:true,
        handler(val){
        if(!this.isEdit){
            // 判断发现是新增，则把所有数据置空
            Object.assign(this.goods,{
                categories: [], // 商品分类信息
                brandId: 0,// 品牌id信息
                title: '',// 标题
                subTitle: '',// 子标题
                spuDetail: {
                    packingList: '',// 包装列表
                    afterService: '',// 售后服务
                    description: '',// 商品描述
                },
            });
            this.specifications = [];
        }else{
            // 发现是修改，则回显数据
            this.goods = Object.deepCopy(val);
        }
    }
}
```

因为页面的很多属性直接与goods绑定，因此发现一些数据已经回显了：

 ![1526385867453](assets/1526385867453.png)

还有商品描述：

![1526385892753](assets/1526385892753.png)



目前，还有几个地方没有回显：

1. 商品分类和品牌
2. 商品规格参数
3. sku属性

我们分别来看

## 1.4.商品分类和品牌回显

分类和品牌数据其实已经拿到：

 ![1526386942020](assets/1526386942020.png)

为什么没有回显呢？

- 商品分类是因为数据格式不正确，页面绑定的是categories属性，要求是数组，要包含id和name
- 品牌没有显示是因为品牌需要根据分类来查询，因此解决了分类，品牌自然就回显了。



我们在监听到oldGoods后，组织商品分类数据：

 ![1526387297499](assets/1526387297499.png)



重新打开编辑页面，发现数据来了：

 ![1526387331730](assets/1526387331730.png)



## 1.5.商品规格参数回显

商品的规格参数其实我们也查到了，就在spuDetail中：

 ![1526387517052](assets/1526387517052.png)



但是，有两点要注意：

- 第一，这里拿到的是json字符串，还不是JS对象
- 第二，这里只有规格参数的值，没有规格参数的待选项options。我们不能用它代替页面的specifications模板

我们要做什么？

- 首先，把json 字符串变为java对象

- 然后，把得到的规格对象中的的值，填充到页面的specifications对象中

什么时候做这件事？

- 最合适的时机莫过于在页面的specifications加载完成以后。



编写代码：

 ![1526389024731](assets/1526389024731.png)

关键代码：

```js
// 判断当前是否是编辑状态，如果是，开始对规格参数进行回显
if(this.isEdit){
    // 得到回显数据中的规格模板, 需要进行json反序列化
    const specs = JSON.parse(this.goods.spuDetail.specifications);
    // 遍历规格参数，并且回显
    this.specifications.forEach((spec,i) => {
        spec.params.forEach((param, j) => {
            param.v = specs[i].params[j].v;
        })
    })
}
```

效果：

![1526389165905](assets/1526389165905.png)

## 1.6.sku属性回显

sku属性的回显分两部分：

- 特有规格属性的回显
- sku列表回显

### 1.6.1.特有规格属性回显

特有规格属性，其实在我们的goods的spuDetail中，已经存在了：

![1526390716069](assets/1526390716069.png)

但是要注意数据格式上的差异。

- 我们是json字符串，需要转JS对象
- key是规格参数名称，值是用户选择的备选项数组

而特有规格模板是这样的：

 ![1526390853686](assets/1526390853686.png)

我们要做的事情：

- 把规格模板反序列化为JS对象
- 把规格模板的值，填写到specialSpecs的selected中。

什么时候做？

- 当然是specialSpecs被初始化完毕后：

代码：

 ![1526390970314](assets/1526390970314.png)

关键部分代码：

```js
// 判断是否是编辑，如果是，对特有规格属性进行回显
if(this.isEdit){
    // 得到回显数据中的特有规格属性值:
    const template = JSON.parse(this.goods.spuDetail.specTemplate);
    // 遍历特有规格参数，回显数据
    this.specialSpecs.forEach(s => {
        s.selected = template[s.k];
    })
}
```

效果：

 ![1526391801204](assets/1526391801204.png)



### 1.6.2.sku列表回显

#### 分析

sku列表其实已经生成了：

![1526391892602](assets/1526391892602.png)

但问题是：价格、库存、是否启用等数据没有显示出来。



因此，我们需要先去查询所有的SKU数据，然后来做回显



#### 后台提供查询SKU接口：

controller

```java
@GetMapping("sku/list")
public ResponseEntity<List<Sku>> querySkuBySpuId(@RequestParam("id") Long id) {
    List<Sku> skus = this.goodsService.querySkuBySpuId(id);
    if (skus == null || skus.size() == 0) {
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    return ResponseEntity.ok(skus);
}
```



service

```java
public List<Sku> querySkuBySpuId(Long spuId) {
    // 查询sku
    Sku record = new Sku();
    record.setSpuId(spuId);
    List<Sku> skus = this.skuMapper.select(record);
    for (Sku sku : skus) {
        // 同时查询出库存
        sku.setStock(this.stockMapper.selectByPrimaryKey(sku.getId()).getStock());
    }
    return skus;
}
```

测试：

  ![1526393046227](assets/1526393046227.png)



#### 页面查询SKU数据：

什么时候去查询这些数据？

有两种思路

- 思路1：在编辑页面刚刚打开之前，因为skus是计算属性，页面加载就会执行渲染，在渲染之前把数据准备好。
- 思路2：等到页面的SKU列表完全准备好，再去修改SKU属性，修改时机会比较晚一点。



思路1比较难一点，但是效率更高。

思路2比较简单，但是需要进行两次渲染



我们选哪种？思路1。



既然是思路1，那么就需要在页面加载前渲染，也就是在父组件：MyGoods中渲染：

这里的难点是，在MyGoods页面editGoods方法中，已经对spuDetail进行了一次异步加载：

 ![1526396114446](assets/1526396114446.png)

现在，如果我们再对sku进行异步加载。那么就有两个异步请求。



我们的要求时，要在两个异步请求都结束后，才能打开窗口。如何实现？

axios工具提供了一个批量请求的方法，可以实现这个效果，一起了解一下：

```
axios.all()方法，接收多个request的数组，返回一个promise

axios.spread()方法，接收回调函数，参数是axios.all方法执行的每个请求的结果。
```

我们在MyGoods页面的editGoods方法中，这么做：

```js
// 发起请求，查询商品详情和skus
this.$http.all([
    this.$http.get("/item/spu/detail/" + oldGoods.id), // 查询商品详情
    this.$http.get("/item/sku/list?id=" + oldGoods.id) // 查询sku
]).then(this.$http.spread(({data: spuDetail}, {data: skus}) => {
    oldGoods.spuDetail = spuDetail;
    oldGoods.skus = skus;
    // 修改标记
    this.isEdit = true;
    // 控制弹窗可见：
    this.show = true;
    // 获取要编辑的goods
    this.oldGoods = oldGoods;
}))
```

查看效果：

 ![1526397381733](assets/1526397381733.png)



#### 实现回显

需要我们回显的数据是哪些？

- 规格属性已经不需要了，只需要：price，images，indexes，enable，stock

在哪里进行回填合适呢？

- 页面的skus是通过计算属性生成的，最合适的加载时机，应该是在那里。



我们需要把刚才goods中的skus的属性 赋值到 生成的skus模板中。两边的sku如何进行匹配呢？

- sku的中有一个属性，indexes，其值在同一个spu的多个sku中一定是唯一的。我们可以根据它进行匹配。



既然要根据sku的indexes属性进行品牌，那么我们如果把goods中的skus数组变为一个以indexes为key的map，等下处理起来就会非常方便。

所以，我们在接收到oldGoods以后，对其中的skus进行处理：

 ![1526397972982](assets/1526397972982.png)



然后，在skus的计算属性中，回显数据：

![1526644252403](assets/1526644252403.png)

特别要注意的是：价格需要转成以元为单位哦

效果：

![1526644357956](assets/1526644357956.png)



## 1.7.提交数据到后台

点击保存，依然还是以前的逻辑，不需要修改。



不过，我们需要根据isEdit来判断到底发起的是Post还是Put请求。

 ![1526398271345](assets/1526398271345.png)



## 1.8.后台实现修改

### 1.8.1.Controller

```java
/**
 * 新增商品
 * @param spu
 * @return
 */
@PutMapping
public ResponseEntity<Void> updateGoods(@RequestBody SpuBo spu) {
    try {
        this.goodsService.update(spu);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    } catch (Exception e) {
        e.printStackTrace();
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
```



### 1.8.2.Service

代码：

```java
@Transactional
public void update(SpuBo spu) {
    // 查询以前sku
    List<Sku> skus = this.querySkuBySpuId(spu.getId());
    // 如果以前存在，则删除
    if(!CollectionUtils.isEmpty(skus)) {
        List<Long> ids = skus.stream().map(s -> s.getId()).collect(Collectors.toList());
        // 删除以前库存
        Example example = new Example(Stock.class);
        example.createCriteria().andIn("skuId", ids);
        this.stockMapper.deleteByExample(example);

        // 删除以前的sku
        Sku record = new Sku();
        record.setSpuId(spu.getId());
        this.skuMapper.delete(record);

    }
    // 新增sku和库存
    saveSkuAndStock(spu.getSkus(), spu.getId());

    // 更新spu
    spu.setLastUpdateTime(new Date());
    spu.setCreateTime(null);
    spu.setValid(null);
    spu.setSaleable(null);
    this.spuMapper.updateByPrimaryKeySelective(spu);

    // 更新spu详情
    this.spuDetailMapper.updateByPrimaryKeySelective(spu.getSpuDetail());
}
```

这里有一点要注意的：

- 页面对sku的修改是不可预知的，甚至可能以前的sku属性都不存在了。比如以前有4G，现在没了。所以我们不能去修改SKU，而是采用删除所有，再重新添加的方式。

### 1.8.3.mapper

与以前一样。



## 1.9.其它

商品还有一个删除和下架的功能，留作作业给大家练习吧



# 2.搭建前台系统

后台系统的内容暂时告一段落，有了商品，接下来我们就要在页面展示商品，给用户提供浏览和购买的入口，那就是我们的门户系统。

门户系统面向的是用户，安全性很重要，而且搜索引擎对于单页应用并不友好。因此我们的门户系统不再采用与后台系统类似的SPA（单页应用）。

依然是前后端分离，不过前端的页面会使用独立的html，在每个页面中使用vue来做页面渲染。

## 2.1.静态资源

webpack打包多页应用配置比较繁琐，项目结构也相对复杂。这里为了简化开发（毕竟我们不是专业的前端人员），我们不在使用webpack，而是直接编写原生的静态HTML。

### 2.1.1.创建工程

创建一个新的工程：

![1526460361784](assets/1526460361784.png)



### 2.1.2.导入静态资源

将课前资料中的leyou-portal解压，并复制到这个项目下

 ![1526460560069](assets/1526460560069.png)

解压缩：

 ![1526460681615](assets/1526460681615.png)

项目结构：

 ![1526460701617](assets/1526460701617.png)

## 2.2.live-server

没有webpack，我们就无法使用webpack-dev-server运行这个项目，实现热部署。

所以，这里我们使用另外一种热部署方式：live-server，

### 2.2.1.简介

地址；https://www.npmjs.com/package/live-server

 ![1526460917348](assets/1526460917348.png)

这是一款带有热加载功能的小型开发服务器。用它来展示你的HTML / JavaScript / CSS，但不能用于部署最终的网站。 

### 2.2.2.安装和运行参数

安装，使用npm命令即可，这里建议全局安装，以后任意位置可用

```
npm install -g live-server
```



运行时，直接输入命令：

```
live-server
```

另外，你可以在运行命令后，跟上一些参数以配置：

- `--port=NUMBER` - 选择要使用的端口，默认值：PORT env var或8080
- `--host=ADDRESS` - 选择要绑定的主机地址，默认值：IP env var或0.0.0.0（“任意地址”）
- `--no-browser` - 禁止自动Web浏览器启动
- `--browser=BROWSER` - 指定使用浏览器而不是系统默认值
- `--quiet | -q` - 禁止记录
- `--verbose | -V` - 更多日志记录（记录所有请求，显示所有侦听的IPv4接口等）
- `--open=PATH` - 启动浏览器到PATH而不是服务器root
- `--watch=PATH` - 用逗号分隔的路径来专门监视变化（默认值：观看所有内容）
- `--ignore=PATH`- 要忽略的逗号分隔的路径字符串（[anymatch](https://github.com/es128/anymatch) -compatible definition）
- `--ignorePattern=RGXP`-文件的正则表达式忽略（即`.*\.jade`）（**不推荐使用**赞成`--ignore`）
- `--middleware=PATH` - 导出要添加的中间件功能的.js文件的路径; 可以是没有路径的名称，也可以是引用`middleware`文件夹中捆绑的中间件的扩展名
- `--entry-file=PATH` - 提供此文件（服务器根目录）代替丢失的文件（对单页应用程序有用）
- `--mount=ROUTE:PATH` - 在定义的路线下提供路径内容（可能有多个定义）
- `--spa` - 将请求从/ abc转换为/＃/ abc（方便单页应用）
- `--wait=MILLISECONDS` - （默认100ms）等待所有更改，然后重新加载
- `--htpasswd=PATH` - 启用期待位于PATH的htpasswd文件的http-auth
- `--cors` - 为任何来源启用CORS（反映请求源，支持凭证的请求）
- `--https=PATH` - 到HTTPS配置模块的路径
- `--proxy=ROUTE:URL` - 代理ROUTE到URL的所有请求
- `--help | -h` - 显示简洁的使用提示并退出
- `--version | -v` - 显示版本并退出

### 2.2.3.测试

我们进入leyou-portal目录，输入命令：

```
live-server --port=9002
```

 ![1526462494331](assets/1526462494331.png)



## 2.3.域名访问

现在我们访问只能通过：http://127.0.0.1:9002

我们希望用域名访问：http://www.leyou.com

第一步，修改hosts文件，添加一行配置：

```
127.0.0.1 www.leyou.com
```

第二步，修改nginx配置，将www.leyou.com反向代理到127.0.0.1:9002

```nginx
server {
    listen       80;
    server_name  www.leyou.com;

    proxy_set_header X-Forwarded-Host $host;
    proxy_set_header X-Forwarded-Server $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    location / {
        proxy_pass http://127.0.0.1:9002;
        proxy_connect_timeout 600;
        proxy_read_timeout 600;
    }
}
```

重新加载nginx配置：`nginx.exe -s reload`

![1526462774092](assets/1526462774092.png)





## 2.4.common.js

为了方便后续的开发，我们在前台系统中定义了一些工具，放在了common.js中：

 ![1526643361038](assets/1526643361038.png)



部分代码截图：

 ![1526643526973](assets/1526643526973.png)

- 首先对axios进行了一些全局配置，请求超时时间，请求的基础路径，是否允许跨域操作cookie等
- 定义了对象 ly ，也叫leyou，包含了下面的属性：
  - getUrlParam(key)：获取url路径中的参数
  - http：axios对象的别名。以后发起ajax请求，可以用ly.http.get()
  - store：localstorage便捷操作，后面用到再详细说明
  - formatPrice：格式化价格，如果传入的是字符串，则扩大100被并转为数字，如果传入是数字，则缩小100倍并转为字符串
  - formatDate(val, pattern)：对日期对象val按照指定的pattern模板进行格式化
  - stringify：将对象转为参数字符串
  - parse：将参数字符串变为js对象